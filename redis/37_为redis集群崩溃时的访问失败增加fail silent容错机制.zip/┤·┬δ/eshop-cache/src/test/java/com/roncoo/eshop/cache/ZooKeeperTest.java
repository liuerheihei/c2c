package com.roncoo.eshop.cache;

import com.roncoo.eshop.cache.zk.ZooKeeperSession;

public class ZooKeeperTest {
	
	public static void main(String[] args) {
		ZooKeeperSession zkSession = ZooKeeperSession.getInstance();
	}
	
}
